Algorithme Fonction_Logique_et_Formes_Canoniques
    Variables :
        a, b, c : booléen
        resultat : booléen
        termes_premiere_forme, termes_seconde_forme : liste de chaînes de caractères

    Début
        Afficher "Table de vérité de la fonction logique [(a and not b) or (b and c)] :"
        Pour chaque combinaison possible de valeurs de a, b et c :
            Pour a allant de Vrai à Faux :
                Pour b allant de Vrai à Faux :
                    Pour c allant de Vrai à Faux :
                        Calculer le résultat de la fonction logique pour les valeurs actuelles de a, b et c
                        Afficher les valeurs de a, b, c et le résultat de la fonction logique

        Pour chaque combinaison possible de valeurs de a, b et c :
            Pour a allant de Vrai à Faux :
                Pour b allant de Vrai à Faux :
                    Pour c allant de Vrai à Faux :
                        Si la fonction logique est vraie pour les valeurs actuelles de a, b et c :
                            Ajouter le terme correspondant à la première forme canonique dans termes_premiere_forme
                        Sinon :
                            Ajouter le terme correspondant à la seconde forme canonique dans termes_seconde_forme

        Afficher "Première forme canonique :"
        Afficher la concaténation des termes de termes_premiere_forme séparés par des " + "
        
        Afficher "Seconde forme canonique :"
        Afficher la concaténation des termes de termes_seconde_forme séparés par des " + "
    Fin